﻿namespace BitDiamond.Core.Models
{
    public enum AccountStatus
    {
        Active,
        InActive,
        Blocked
    }
}
