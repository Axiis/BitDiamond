﻿using Axis.Luna;
using System;
using System.ComponentModel.DataAnnotations;
using static Axis.Luna.Extensions.ObjectExtensions;

namespace BitDiamond.Data.EF.Entities
{
    public class SystemSetting : Core.Models.SystemSetting
    {
        public SystemSetting()
        {
        }
    }
}
